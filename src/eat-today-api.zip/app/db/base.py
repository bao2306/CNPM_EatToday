
# For Alembic discovery (import models here if needed)
from ..models.user import User  # noqa
from ..models.meal import Meal  # noqa
