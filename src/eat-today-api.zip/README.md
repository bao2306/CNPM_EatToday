
# Eat Today API (FastAPI)

API quản lý dữ liệu người dùng và bữa ăn cho ứng dụng **Eat Today**. Bao gồm:
- Đăng ký / đăng nhập (JWT)
- Hồ sơ người dùng
- Ghi nhận bữa ăn theo ngày
- Gợi ý món ăn cơ bản
- Test tự động (pytest)
- Docker & docker-compose

## Cấu trúc thư mục

```
eat-today-api/
  app/
    api/
      v1/
        auth.py
        users.py
        meals.py
      deps.py
    core/
      config.py
      security.py
    db/
      base.py
      session.py
    models/
      user.py
      meal.py
    schemas/
      user.py
      meal.py
    services/
      suggestions.py
    main.py
  tests/
    conftest.py
    test_auth.py
    test_meals.py
  .env.example
  requirements.txt
  Dockerfile
  docker-compose.yml
  README.md
  .gitignore
```

## Chạy nhanh (local)

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

Mở Swagger UI: http://127.0.0.1:8000/docs

## Docker

```bash
cp .env.example .env
docker compose up --build
```

## Test

```bash
pytest -q
```

## Đổi DB sang Postgres (tùy chọn)

- Sửa `SQLALCHEMY_DATABASE_URI` trong `.env`
- Cập nhật `docker-compose.yml` để bật dịch vụ `db` (Postgres)
- (Tùy chọn) dùng Alembic để migration

## Deploy nhanh lên Render/Fly/VM
- Build Docker image từ `Dockerfile`
- Set biến môi trường từ `.env`
- Expose cổng 8000

## Đẩy lên GitHub

```bash
git init
git add .
git commit -m "feat: initial Eat Today API"
git branch -M main
git remote add origin https://github.com/<your-username>/eat-today-api.git
git push -u origin main
```
